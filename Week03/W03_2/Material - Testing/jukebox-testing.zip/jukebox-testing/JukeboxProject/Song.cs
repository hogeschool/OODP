
public class Song
{
    public string Title;
    public string Artist;

    public Song(string title, string artist)
    {
        Title = title;
        Artist = artist;
    }

    public string Info()
    {
        return $"'{Title}' performed by '{Artist}'";
    }
}