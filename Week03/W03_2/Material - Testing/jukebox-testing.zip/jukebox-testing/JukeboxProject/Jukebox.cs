public class Jukebox
{
    public List<Song> Playlist = [];

    public void AddSong(string title, string artist)
    {
        Playlist.Add(new Song(title, artist));
    }

    public string PlaySong(int songIndex)
    {
        if (Playlist.Count() == 0)
        {
            return "No songs currently in Playlist!";
        }
        if (songIndex < 0 || songIndex >= Playlist.Count)
        {
            return "Invalid song number";
        }
        return $"Playing {Playlist[songIndex].Info()}";
    }
}