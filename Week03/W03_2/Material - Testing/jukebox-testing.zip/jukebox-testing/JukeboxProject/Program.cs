﻿public class Program
{
    public static void Main(string[] args)
    {
        Jukebox jukebox = new Jukebox();
        jukebox.AddSong("Imagine", "John Lennon");
        jukebox.AddSong("Bohemian Rhapsody", "Queen");
        jukebox.AddSong("Hotel California", "Eagles");
        jukebox.AddSong("Hey Jude", "The Beatles");
        jukebox.AddSong("Like a Rolling Stone", "Bob Dylan");

        for (int i = 0; i < jukebox.Playlist.Count; i++)
        {
            Console.WriteLine(jukebox.PlaySong(i));
        }
    }
}