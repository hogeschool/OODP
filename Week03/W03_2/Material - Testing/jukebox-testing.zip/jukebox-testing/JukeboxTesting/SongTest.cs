[TestClass]
public class SongTests
{
    [TestMethod]
    public void Constructor_WithValidInputs_InitializesTitleAndArtist()
    {
        // Arrange
        string expectedTitle = "Imagine";
        string expectedArtist = "John Lennon";

        // Act
        var song = new Song(expectedTitle, expectedArtist);

        // Assert
        Assert.AreEqual(expectedTitle, song.Title);
        Assert.AreEqual(expectedArtist, song.Artist);
    }

    [TestMethod]
    public void Info_WithValidSong_ReturnsFormattedTitleAndArtist()
    {
        // Arrange
        var song = new Song("Imagine", "John Lennon");

        // Act
        var info = song.Info();

        // Assert
        Assert.AreEqual("'Imagine' performed by 'John Lennon'", info);
    }
}

