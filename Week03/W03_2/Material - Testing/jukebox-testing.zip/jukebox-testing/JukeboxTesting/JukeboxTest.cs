// Indicates that this class contains tests
[TestClass]
public class JukeboxTest
{

    // All methods with this tag will run when `dotnet mstest` is executed
    [TestMethod]
    public void AddSong_Add_SongAdded()
    {
        // Arrange
        Jukebox jukebox = new Jukebox();
        string title = "Imagine";
        string artist = "John Lennon";

        // Act
        jukebox.AddSong(title, artist);

        // Assert
        string actualTitle = jukebox.Playlist[^1].Title;
        string actualArtist = jukebox.Playlist[^1].Artist;

        Assert.AreEqual(1, jukebox.Playlist.Count);
        Assert.AreEqual(title, actualTitle);
        Assert.AreEqual(artist, actualArtist);
    }

    [TestMethod]
    // We can use the DataRow attribute to  to run the same test method with multiple different inputs
    [DataRow("Imagine", "John Lennon")]
    [DataRow("Bohemian Rhapsody", "Queen")]
    [DataRow("", "")]
    // The data comes in via the parameters
    public void AddSong_WithVariousInputs_AddsCorrectly(string title, string artist)
    {
        // Arrange
        Jukebox jukebox = new Jukebox();

        // Act
        jukebox.AddSong(title, artist);

        // Assert
        string actualTitle = jukebox.Playlist[^1].Title;
        string actualArtist = jukebox.Playlist[^1].Artist;

        Assert.AreEqual(1, jukebox.Playlist.Count);
        Assert.AreEqual(title, actualTitle);
        Assert.AreEqual(artist, actualArtist);
    }


    [TestMethod]
    public void PlaySong_ValidIndex_ReturnsPlayingMessage()
    {
        // Arrange
        Jukebox jukebox = new Jukebox();
        jukebox.AddSong("Imagine", "John Lennon");

        // Act
        string actual = jukebox.PlaySong(0);

        // Assert
        string expected = "Playing 'Imagine' performed by 'John Lennon'";
        Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void PlaySong_NoSongsInPlaylist_ReturnsNoSongsMessage()
    {
        // Arrange
        Jukebox jukebox = new Jukebox();

        // Act
        var actual = jukebox.PlaySong(0);

        // Assert
        string expected = "No songs currently in Playlist!";
        Assert.AreEqual(expected, actual);
    }


    [TestMethod]
    [DataRow(-2)]
    [DataRow(-1)]
    [DataRow(1)]
    [DataRow(2)]
    public void PlaySong_InvalidIndex_ReturnsInvalidSongMessage(int songIndex)
    {
        // Arrange
        Jukebox jukebox = new Jukebox();
        jukebox.AddSong("Imagine", "John Lennon");

        // Act
        string actual = jukebox.PlaySong(songIndex);

        // Assert
        string expected = "Invalid song number";
        Assert.AreEqual(expected, actual);
    }
}